import React, { useState } from 'react';
import { UserProfile, ArticleCategory, SupportedLanguage } from '../types';
import { TRANSLATIONS } from '../lib/translations';
import { INDIAN_STATES } from '../data/indiaMapData';
import { Search, PlusCircle, Globe, Sun, Moon, Shield, User as UserIcon, Flame, Radio, Menu, X } from 'lucide-react';

interface HeaderProps {
  user: UserProfile | null;
  selectedCategory: string;
  selectedState: string;
  searchQuery: string;
  selectedLanguage: SupportedLanguage;
  darkMode: boolean;
  onSelectCategory: (cat: string) => void;
  onSelectState: (st: string) => void;
  onSearchChange: (q: string) => void;
  onLanguageChange: (lang: SupportedLanguage) => void;
  onToggleDarkMode: () => void;
  onOpenPublishModal: () => void;
  onOpenAuthModal: () => void;
  onOpenProfileModal: () => void;
  onOpenAdminModal: () => void;
}

const CATEGORIES: string[] = [
  'All',
  'Breaking News',
  'Local News',
  'National News',
  'Politics',
  'Technology',
  'Agriculture',
  'Sports',
  'Business',
  'Entertainment',
  'Education',
  'Health',
  'Crime',
  'Weather',
  'Events',
];

const LANGUAGES: { code: SupportedLanguage; label: string }[] = [
  { code: 'en', label: 'English' },
  { code: 'hi', label: 'हिंदी (Hindi)' },
  { code: 'mr', label: 'मराठी (Marathi)' },
  { code: 'ta', label: 'தமிழ் (Tamil)' },
  { code: 'te', label: 'తెలుగు (Telugu)' },
  { code: 'bn', label: 'বাংলা (Bengali)' },
  { code: 'kn', label: 'ಕನ್ನಡ (Kannada)' },
  { code: 'ml', label: 'മലയാളം (Malayalam)' },
  { code: 'gu', label: 'ગુજરાતી (Gujarati)' },
  { code: 'pa', label: 'ਪੰਜਾਬੀ (Punjabi)' },
];

export const Header: React.FC<HeaderProps> = ({
  user,
  selectedCategory,
  selectedState,
  searchQuery,
  selectedLanguage,
  darkMode,
  onSelectCategory,
  onSelectState,
  onSearchChange,
  onLanguageChange,
  onToggleDarkMode,
  onOpenPublishModal,
  onOpenAuthModal,
  onOpenProfileModal,
  onOpenAdminModal,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const t = TRANSLATIONS[selectedLanguage] || TRANSLATIONS.en;

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 shadow-sm transition-colors">
      {/* Top Utility Bar */}
      <div className="bg-slate-950 text-slate-300 text-[11px] py-1.5 px-3 sm:px-6 flex items-center justify-between border-b border-slate-800">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5 text-orange-400 font-extrabold uppercase tracking-wider">
            <Radio className="w-3 h-3 text-red-500 animate-ping" />
            Citizen Network Active
          </span>
          <span className="hidden md:inline text-slate-400">
            Real-time verified journalism across 28 States & UTs
          </span>
        </div>

        <div className="flex items-center gap-3">
          {/* Language Picker */}
          <div className="flex items-center gap-1 bg-slate-900 px-2 py-0.5 rounded border border-slate-700">
            <Globe className="w-3 h-3 text-orange-400 shrink-0" />
            <select
              value={selectedLanguage}
              onChange={(e) => onLanguageChange(e.target.value as SupportedLanguage)}
              className="bg-transparent text-slate-200 text-[11px] focus:outline-none cursor-pointer"
            >
              {LANGUAGES.map((l) => (
                <option key={l.code} value={l.code} className="bg-slate-900 text-white">
                  {l.label}
                </option>
              ))}
            </select>
          </div>

          {/* Dark Mode Toggle */}
          <button
            onClick={onToggleDarkMode}
            className="p-1 hover:text-white rounded text-slate-300 transition-colors"
            title="Toggle Theme"
          >
            {darkMode ? <Sun className="w-3.5 h-3.5 text-amber-300" /> : <Moon className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Main Header Brand & Actions */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-3 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-tr from-orange-600 via-orange-500 to-amber-500 flex items-center justify-center text-white font-black text-xl shadow-lg shadow-orange-500/20 ring-2 ring-orange-400/30">
            BNN
          </div>
          <div>
            <h1 className="text-lg sm:text-2xl font-black tracking-tight text-slate-900 dark:text-white flex items-center gap-1.5 leading-none">
              <span>Bharat</span>
              <span className="text-orange-600 dark:text-orange-500">News</span>
            </h1>
            <p className="text-[10px] sm:text-xs font-semibold text-slate-500 dark:text-slate-400 tracking-wide mt-0.5">
              {t.tagline}
            </p>
          </div>
        </div>

        {/* Search Bar (Desktop) */}
        <div className="hidden lg:flex flex-1 max-w-md relative">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            placeholder={t.searchPlaceholder}
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full pl-10 pr-4 py-2 text-xs sm:text-sm bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 rounded-2xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500 transition-all"
          />
          {searchQuery && (
            <button onClick={() => onSearchChange('')} className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-slate-600">
              Clear
            </button>
          )}
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Post News Button */}
          <button
            onClick={onOpenPublishModal}
            className="bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 text-white text-xs sm:text-sm font-extrabold px-3.5 sm:px-4 py-2 rounded-xl shadow-md transition-all flex items-center gap-1.5"
          >
            <PlusCircle className="w-4 h-4" />
            <span className="hidden sm:inline">{t.postNewsBtn}</span>
          </button>

          {/* Admin Dashboard Trigger (if admin/moderator) */}
          {(user?.role === 'admin' || user?.role === 'moderator') && (
            <button
              onClick={onOpenAdminModal}
              className="p-2 sm:px-3 sm:py-2 bg-slate-900 text-white rounded-xl text-xs font-bold flex items-center gap-1 hover:bg-slate-800 transition-colors"
              title="Admin Dashboard"
            >
              <Shield className="w-4 h-4 text-orange-400" />
              <span className="hidden md:inline">Admin</span>
            </button>
          )}

          {/* Profile / Auth Button */}
          {user ? (
            <button
              onClick={onOpenProfileModal}
              className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 p-1.5 sm:pr-3 rounded-2xl transition-colors border border-slate-200 dark:border-slate-700"
            >
              <img
                src={user.avatar}
                alt={user.name}
                referrerPolicy="no-referrer"
                className="w-7 h-7 rounded-full object-cover ring-2 ring-orange-500"
              />
              <span className="hidden md:inline text-xs font-bold text-slate-800 dark:text-slate-200 truncate max-w-[100px]">
                {user.name.split(' ')[0]}
              </span>
            </button>
          ) : (
            <button
              onClick={onOpenAuthModal}
              className="px-3 py-2 bg-slate-900 text-white text-xs font-bold rounded-xl hover:bg-slate-800 transition-colors"
            >
              {t.loginRegister}
            </button>
          )}

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 lg:hidden text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Categories Navigation Bar */}
      <div className="bg-slate-50 dark:bg-slate-900/60 border-t border-slate-200/80 dark:border-slate-800 overflow-x-auto custom-scrollbar">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 flex items-center gap-1.5 py-2 text-xs">
          {CATEGORIES.map((cat) => {
            const active = selectedCategory.toLowerCase() === cat.toLowerCase();
            return (
              <button
                key={cat}
                onClick={() => onSelectCategory(cat)}
                className={`whitespace-nowrap px-3 py-1.5 rounded-xl font-extrabold transition-all shrink-0 ${
                  active
                    ? 'bg-orange-600 text-white shadow-sm'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-slate-800'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden p-4 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder={t.searchPlaceholder}
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-100 dark:bg-slate-800 rounded-xl"
            />
          </div>

          <div className="flex items-center justify-between text-xs pt-2">
            <span className="font-bold text-slate-600 dark:text-slate-400">Filter State:</span>
            <select
              value={selectedState}
              onChange={(e) => onSelectState(e.target.value)}
              className="bg-slate-100 dark:bg-slate-800 p-1.5 rounded-lg text-xs"
            >
              <option value="All">All India</option>
              {INDIAN_STATES.map((st) => (
                <option key={st.id} value={st.name}>
                  {st.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      )}
    </header>
  );
};
