import React, { useState } from 'react';
import { LiveUpdateItem } from '../types';
import { INDIAN_STATES } from '../data/indiaMapData';
import { TranslationStrings } from '../lib/translations';
import { AlertTriangle, Send, Image as ImageIcon, MapPin, Heart, MessageSquare, Share2, ShieldAlert, Sparkles, Flame } from 'lucide-react';

interface LiveFeedSectionProps {
  items: LiveUpdateItem[];
  t: TranslationStrings;
  onPostUpdate: (newItem: Partial<LiveUpdateItem>) => void;
}

export const LiveFeedSection: React.FC<LiveFeedSectionProps> = ({
  items,
  t,
  onPostUpdate,
}) => {
  const [content, setContent] = useState('');
  const [selectedState, setSelectedState] = useState('Uttar Pradesh');
  const [photoUrl, setPhotoUrl] = useState('');
  const [isEmergency, setIsEmergency] = useState(false);
  const [showPhotoInput, setShowPhotoInput] = useState(false);
  const [filterState, setFilterState] = useState('All');

  const handlePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;

    onPostUpdate({
      content,
      state: selectedState,
      district: 'Local Zone',
      category: isEmergency ? 'Emergency Alert' : 'Local Update',
      mediaType: photoUrl ? 'photo' : 'alert',
      mediaUrls: photoUrl ? [photoUrl] : [],
      isEmergencyAlert: isEmergency,
    });

    setContent('');
    setPhotoUrl('');
    setIsEmergency(false);
    setShowPhotoInput(false);
  };

  const filteredItems = items.filter(
    item => filterState === 'All' || item.state.toLowerCase() === filterState.toLowerCase()
  );

  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 rounded-2xl p-5 sm:p-6 text-white border border-slate-800 shadow-xl space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="inline-flex items-center gap-1.5 bg-red-600/20 text-red-400 border border-red-500/30 px-2.5 py-0.5 rounded-full text-[11px] font-extrabold uppercase tracking-wider mb-1">
            <Flame className="w-3.5 h-3.5 text-red-500 animate-pulse" />
            <span>Citizen Real-Time Social Stream</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
            {t.whatsHappening}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Verified local alerts, traffic, weather, incidents, and festival moments directly from ground reporters.
          </p>
        </div>

        {/* State Quick Filter */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-medium shrink-0">Filter:</span>
          <select
            value={filterState}
            onChange={(e) => setFilterState(e.target.value)}
            className="bg-slate-800 border border-slate-700 text-xs text-slate-200 px-3 py-1.5 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500"
          >
            <option value="All">All India Stream</option>
            {INDIAN_STATES.map((st) => (
              <option key={st.id} value={st.name}>
                {st.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Quick Citizen Post Input Box */}
      <form onSubmit={handlePost} className="bg-slate-800/80 p-4 rounded-xl border border-slate-700/80 space-y-3">
        <textarea
          rows={2}
          placeholder="Share what is happening around you right now (traffic, weather, public alerts, local incidents)..."
          value={content}
          onChange={(e) => setContent(e.target.value)}
          className="w-full bg-slate-900 border border-slate-700/80 rounded-xl p-3 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-orange-500"
        />

        {showPhotoInput && (
          <input
            type="text"
            placeholder="Paste Photo URL..."
            value={photoUrl}
            onChange={(e) => setPhotoUrl(e.target.value)}
            className="w-full bg-slate-900 border border-slate-700/80 rounded-xl p-2.5 text-xs text-white focus:outline-none"
          />
        )}

        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <div className="flex items-center gap-2">
            {/* Select State */}
            <select
              value={selectedState}
              onChange={(e) => setSelectedState(e.target.value)}
              className="bg-slate-900 border border-slate-700 text-[11px] text-slate-300 px-2.5 py-1 rounded-lg"
            >
              {INDIAN_STATES.map((s) => (
                <option key={s.id} value={s.name}>
                  📍 {s.name}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={() => setShowPhotoInput(!showPhotoInput)}
              className="p-1.5 hover:bg-slate-700 rounded-lg text-slate-300 text-xs flex items-center gap-1 transition-colors"
            >
              <ImageIcon className="w-4 h-4 text-orange-400" />
              <span className="hidden sm:inline">Add Photo</span>
            </button>

            <label className="flex items-center gap-1.5 text-xs cursor-pointer text-slate-300 select-none">
              <input
                type="checkbox"
                checked={isEmergency}
                onChange={(e) => setIsEmergency(e.target.checked)}
                className="rounded border-slate-700 text-red-600 focus:ring-red-500"
              />
              <span className={isEmergency ? 'text-red-400 font-bold flex items-center gap-1' : ''}>
                {isEmergency && <ShieldAlert className="w-3.5 h-3.5 text-red-500" />}
                Emergency Alert
              </span>
            </label>
          </div>

          <button
            type="submit"
            disabled={!content.trim()}
            className="px-4 py-1.5 bg-orange-600 hover:bg-orange-500 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl shadow transition-all flex items-center gap-1.5"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Post Update</span>
          </button>
        </div>
      </form>

      {/* Feed List */}
      <div className="space-y-4 max-h-[500px] overflow-y-auto pr-1 custom-scrollbar">
        {filteredItems.length === 0 ? (
          <div className="text-center py-8 text-slate-500 text-xs">
            No live updates reported for this state yet. Be the first citizen to post!
          </div>
        ) : (
          filteredItems.map((item) => (
            <div
              key={item.id}
              className={`p-4 rounded-xl border transition-all ${
                item.isEmergencyAlert
                  ? 'bg-red-950/40 border-red-800/80'
                  : 'bg-slate-800/50 border-slate-700/60 hover:bg-slate-800'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <img
                    src={item.author.avatar}
                    alt={item.author.name}
                    referrerPolicy="no-referrer"
                    className="w-8 h-8 rounded-full object-cover ring-1 ring-slate-700"
                  />
                  <div>
                    <div className="flex items-center gap-1.5 text-xs font-bold text-white">
                      <span>{item.author.name}</span>
                      <span className="text-[10px] text-slate-400 font-normal">
                        • {item.author.location}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-400">{item.timestamp}</span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <span className="bg-orange-500/20 text-orange-300 border border-orange-500/30 text-[10px] font-bold px-2 py-0.5 rounded">
                    {item.state}
                  </span>
                  {item.isEmergencyAlert && (
                    <span className="bg-red-600 text-white text-[10px] font-black px-2 py-0.5 rounded animate-pulse">
                      ALERT
                    </span>
                  )}
                </div>
              </div>

              {/* Update text */}
              <p className="text-xs sm:text-sm text-slate-200 mt-2.5 leading-relaxed font-normal">
                {item.content}
              </p>

              {/* Update Photos if present */}
              {item.mediaUrls && item.mediaUrls.length > 0 && (
                <div className="mt-3 rounded-xl overflow-hidden max-h-56 border border-slate-700">
                  <img
                    src={item.mediaUrls[0]}
                    alt="Live update media"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
              )}

              {/* Feed Actions */}
              <div className="flex items-center gap-4 mt-3 pt-2 border-t border-slate-700/50 text-xs text-slate-400">
                <button className="flex items-center gap-1 hover:text-red-400 transition-colors">
                  <Heart className="w-3.5 h-3.5" />
                  <span>{item.likes}</span>
                </button>
                <button className="flex items-center gap-1 hover:text-white transition-colors">
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>{item.commentsCount}</span>
                </button>
                <button className="flex items-center gap-1 hover:text-orange-400 transition-colors ml-auto">
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Share</span>
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
