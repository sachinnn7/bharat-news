import React, { useState } from 'react';
import { INDIAN_STATES, IndiaStateData, STATE_DISTRICTS } from '../data/indiaMapData';
import { TranslationStrings } from '../lib/translations';
import { MapPin, Filter, Layers, CheckCircle2, ChevronRight, Search } from 'lucide-react';

interface IndiaMapProps {
  selectedState: string;
  selectedDistrict: string;
  onSelectState: (stateName: string) => void;
  onSelectDistrict: (districtName: string) => void;
  t: TranslationStrings;
}

export const IndiaMap: React.FC<IndiaMapProps> = ({
  selectedState,
  selectedDistrict,
  onSelectState,
  onSelectDistrict,
  t,
}) => {
  const [hoveredState, setHoveredState] = useState<IndiaStateData | null>(null);
  const [mapSearch, setMapSearch] = useState('');

  const filteredStates = INDIAN_STATES.filter(s =>
    s.name.toLowerCase().includes(mapSearch.toLowerCase()) ||
    s.capital.toLowerCase().includes(mapSearch.toLowerCase())
  );

  const activeStateObj = INDIAN_STATES.find(s => s.name === selectedState);
  const availableDistricts = selectedState !== 'All' && STATE_DISTRICTS[selectedState] ? STATE_DISTRICTS[selectedState] : [];

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 shadow-sm border border-slate-200/80 dark:border-slate-800 transition-colors">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-orange-950/50 px-2.5 py-1 rounded-full mb-1">
            <MapPin className="w-3.5 h-3.5" />
            <span>Interactive India Map</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            {t.indiaMapTitle}
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Select any state or district to discover ground reporting from citizen journalists near you.
          </p>
        </div>

        {/* State Search */}
        <div className="relative min-w-[240px]">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search state or capital..."
            value={mapSearch}
            onChange={(e) => setMapSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-orange-500"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Visual Map Canvas / Graphical Interactive Stage */}
        <div className="lg:col-span-7 bg-slate-950 rounded-2xl p-4 sm:p-6 relative min-h-[380px] sm:min-h-[440px] flex flex-col justify-between overflow-hidden border border-slate-800 shadow-inner">
          {/* Subtle Map Grid lines background */}
          <div className="absolute inset-0 bg-[radial-gradient(#334155_1px,transparent_1px)] [background-size:16px_16px] opacity-20 pointer-events-none" />

          {/* Map Header Overlay */}
          <div className="relative z-10 flex items-center justify-between text-xs text-slate-400 border-b border-slate-800 pb-2">
            <span className="font-semibold text-slate-300 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-orange-400" />
              India Regional Geo-Grid
            </span>
            <span className="bg-orange-500/10 text-orange-400 border border-orange-500/20 px-2 py-0.5 rounded text-[10px]">
              28 States & UTs Live
            </span>
          </div>

          {/* Interactive State Nodes Map */}
          <div className="relative w-full h-[300px] sm:h-[340px] my-2">
            {/* SVG India Outline Backdrop */}
            <svg viewBox="0 0 100 100" className="w-full h-full absolute inset-0 opacity-15 pointer-events-none fill-slate-700 stroke-orange-500/30 stroke-[0.5]">
              <path d="M 30,10 Q 35,5 45,15 Q 50,20 60,18 Q 75,25 85,35 Q 90,45 80,50 Q 75,60 60,60 Q 55,75 45,90 Q 35,80 35,70 Q 25,60 20,45 Q 15,35 25,25 Z" />
            </svg>

            {/* Interactive Pins */}
            {INDIAN_STATES.map((state) => {
              const isSelected = selectedState === state.name;
              const isHovered = hoveredState?.id === state.id;

              return (
                <div
                  key={state.id}
                  style={{
                    left: `${state.centerPos.x}%`,
                    top: `${state.centerPos.y}%`,
                  }}
                  className="absolute -translate-x-1/2 -translate-y-1/2 z-20 transition-all duration-300"
                >
                  <button
                    onClick={() => {
                      onSelectState(state.name);
                      onSelectDistrict('All');
                    }}
                    onMouseEnter={() => setHoveredState(state)}
                    onMouseLeave={() => setHoveredState(null)}
                    className={`group relative flex items-center justify-center transition-transform hover:scale-125 focus:outline-none ${
                      isSelected ? 'z-30 scale-125' : ''
                    }`}
                  >
                    {/* Ripple animation for active or breaking states */}
                    {(isSelected || state.newsCount > 120) && (
                      <span className={`absolute inline-flex h-full w-full rounded-full opacity-75 animate-ping ${
                        isSelected ? 'bg-orange-500' : 'bg-amber-400'
                      }`} />
                    )}

                    {/* Pin button */}
                    <div
                      className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center font-extrabold text-[10px] sm:text-xs shadow-lg transition-all border ${
                        isSelected
                          ? 'bg-orange-600 text-white border-white ring-4 ring-orange-500/30'
                          : isHovered
                          ? 'bg-amber-500 text-slate-950 border-amber-200 scale-110'
                          : 'bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700'
                      }`}
                    >
                      {state.code}
                    </div>

                    {/* Tooltip on hover */}
                    {(isHovered || isSelected) && (
                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-max bg-slate-900/95 border border-slate-700 text-white text-[11px] p-2 rounded-lg shadow-xl backdrop-blur-md z-40 pointer-events-none">
                        <div className="font-bold text-orange-400 flex items-center gap-1">
                          {state.name}
                          {isSelected && <CheckCircle2 className="w-3 h-3 text-emerald-400" />}
                        </div>
                        <div className="text-[10px] text-slate-300">Capital: {state.capital}</div>
                        <div className="text-[10px] text-amber-300 font-semibold">{state.newsCount} Citizen Reports</div>
                      </div>
                    )}
                  </button>
                </div>
              );
            })}
          </div>

          {/* Map Footer Banner */}
          <div className="relative z-10 flex items-center justify-between text-xs bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
            <span className="text-slate-300 font-medium">
              Active Filter: <strong className="text-orange-400">{selectedState}</strong>
              {selectedDistrict !== 'All' && <span className="text-slate-400"> › {selectedDistrict}</span>}
            </span>
            {selectedState !== 'All' && (
              <button
                onClick={() => {
                  onSelectState('All');
                  onSelectDistrict('All');
                }}
                className="text-[11px] text-slate-400 hover:text-white underline"
              >
                Reset All India
              </button>
            )}
          </div>
        </div>

        {/* State Selection Grid & District Drill-Down */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
              <Filter className="w-4 h-4 text-orange-500" />
              Select State ({filteredStates.length})
            </h3>
            <button
              onClick={() => {
                onSelectState('All');
                onSelectDistrict('All');
              }}
              className={`text-xs px-2.5 py-1 rounded-lg border font-medium transition-colors ${
                selectedState === 'All'
                  ? 'bg-orange-600 text-white border-orange-600'
                  : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              All India
            </button>
          </div>

          {/* State Badges Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-[220px] overflow-y-auto pr-1 custom-scrollbar">
            {filteredStates.map((st) => {
              const active = selectedState === st.name;
              return (
                <button
                  key={st.id}
                  onClick={() => {
                    onSelectState(st.name);
                    onSelectDistrict('All');
                  }}
                  className={`flex flex-col text-left p-2 rounded-xl text-xs border transition-all ${
                    active
                      ? 'bg-orange-50 dark:bg-orange-950/60 border-orange-500 text-orange-950 dark:text-orange-100 shadow-sm font-semibold ring-1 ring-orange-500'
                      : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700/80 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span className="font-bold truncate">{st.name}</span>
                    <span className="text-[10px] opacity-70 bg-black/10 dark:bg-white/10 px-1 rounded">
                      {st.code}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 mt-1">
                    {st.newsCount} reports
                  </span>
                </button>
              );
            })}
          </div>

          {/* District Selector (If State is active) */}
          {selectedState !== 'All' && availableDistricts.length > 0 && (
            <div className="bg-orange-50/50 dark:bg-slate-800/80 p-3.5 rounded-xl border border-orange-200 dark:border-slate-700/80 mt-2">
              <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 mb-2 flex items-center justify-between">
                <span>Filter District in {selectedState}:</span>
                <span className="text-[10px] font-normal text-slate-500">
                  {availableDistricts.length} Districts
                </span>
              </label>
              <div className="flex flex-wrap gap-1.5 max-h-[120px] overflow-y-auto custom-scrollbar">
                <button
                  onClick={() => onSelectDistrict('All')}
                  className={`text-[11px] px-2.5 py-1 rounded-lg border transition-colors ${
                    selectedDistrict === 'All'
                      ? 'bg-orange-600 text-white border-orange-600 font-semibold'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
                  }`}
                >
                  All Districts
                </button>
                {availableDistricts.map((dist) => (
                  <button
                    key={dist}
                    onClick={() => onSelectDistrict(dist)}
                    className={`text-[11px] px-2.5 py-1 rounded-lg border transition-colors ${
                      selectedDistrict === dist
                        ? 'bg-orange-600 text-white border-orange-600 font-semibold'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    {dist}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
