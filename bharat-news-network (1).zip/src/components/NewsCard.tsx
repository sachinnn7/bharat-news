import React from 'react';
import { NewsArticle } from '../types';
import { TranslationStrings } from '../lib/translations';
import { CheckCircle2, Heart, MessageSquare, Share2, Eye, Clock, Bookmark, Sparkles, AlertTriangle, ShieldCheck } from 'lucide-react';

interface NewsCardProps {
  article: NewsArticle;
  t: TranslationStrings;
  onSelect: (article: NewsArticle) => void;
  onLike: (e: React.MouseEvent, id: string) => void;
  isLiked?: boolean;
  isBookmarked?: boolean;
  onBookmark?: (e: React.MouseEvent, id: string) => void;
  layout?: 'standard' | 'horizontal' | 'compact' | 'hero';
}

export const NewsCard: React.FC<NewsCardProps> = ({
  article,
  t,
  onSelect,
  onLike,
  isLiked = false,
  isBookmarked = false,
  onBookmark,
  layout = 'standard',
}) => {
  const handleShare = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (navigator.share) {
      navigator.share({
        title: article.title,
        text: article.summary || article.title,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('Article link copied to clipboard!');
    }
  };

  const renderFactCheckBadge = () => {
    switch (article.factCheckLabel) {
      case 'verified':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full">
            <ShieldCheck className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
            Verified News
          </span>
        );
      case 'developing':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-amber-500/10 text-amber-700 dark:text-amber-400 border border-amber-500/20 px-2 py-0.5 rounded-full">
            <AlertTriangle className="w-3 h-3 text-amber-600" />
            Developing Story
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-medium bg-slate-500/10 text-slate-600 dark:text-slate-400 px-2 py-0.5 rounded-full">
            Citizen Post
          </span>
        );
    }
  };

  if (layout === 'hero') {
    return (
      <div
        onClick={() => onSelect(article)}
        className="group relative bg-slate-900 rounded-2xl overflow-hidden shadow-xl border border-slate-800 cursor-pointer min-h-[420px] flex flex-col justify-end p-6 transition-all hover:shadow-2xl hover:border-slate-700"
      >
        {/* Background Image with Dark Gradient overlay */}
        <div className="absolute inset-0 z-0">
          <img
            src={article.featuredImage}
            alt={article.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/70 to-transparent" />
        </div>

        {/* Hero Content */}
        <div className="relative z-10 space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <span className="bg-orange-600 text-white font-extrabold text-[11px] uppercase tracking-wider px-2.5 py-1 rounded-md">
              {article.category}
            </span>
            <span className="bg-white/20 backdrop-blur-md text-white font-semibold text-[11px] px-2.5 py-1 rounded-md">
              📍 {article.state}
            </span>
            {renderFactCheckBadge()}
          </div>

          <h1 className="text-xl sm:text-2xl lg:text-3xl font-black text-white leading-tight group-hover:text-orange-300 transition-colors">
            {article.title}
          </h1>

          <p className="text-xs sm:text-sm text-slate-200 line-clamp-2 max-w-3xl">
            {article.summary || article.subtitle || article.content}
          </p>

          {/* Author & Meta */}
          <div className="flex flex-wrap items-center justify-between gap-4 pt-3 border-t border-white/10 text-xs text-slate-300">
            <div className="flex items-center gap-2.5">
              <img
                src={article.author.avatar}
                alt={article.author.name}
                referrerPolicy="no-referrer"
                className="w-7 h-7 rounded-full object-cover ring-2 ring-orange-500"
              />
              <div className="flex items-center gap-1 font-semibold text-white">
                <span>{article.author.name}</span>
                {article.author.verifiedBadge && (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                )}
              </div>
            </div>

            <div className="flex items-center gap-4 text-slate-300">
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-orange-400" />
                {article.readingTimeMinutes} min read
              </span>
              <span className="flex items-center gap-1">
                <Eye className="w-3.5 h-3.5" />
                {article.views.toLocaleString()}
              </span>
              <button
                onClick={(e) => onLike(e, article.id)}
                className={`flex items-center gap-1 font-semibold ${
                  isLiked ? 'text-red-400' : 'hover:text-white'
                }`}
              >
                <Heart className={`w-4 h-4 ${isLiked ? 'fill-red-400 text-red-400' : ''}`} />
                {article.likes}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      onClick={() => onSelect(article)}
      className="group bg-white dark:bg-slate-900 rounded-2xl overflow-hidden border border-slate-200/80 dark:border-slate-800/80 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between cursor-pointer hover:-translate-y-1"
    >
      <div>
        {/* Card Thumbnail */}
        <div className="relative h-48 w-full overflow-hidden bg-slate-100 dark:bg-slate-800">
          <img
            src={article.featuredImage}
            alt={article.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />

          {/* Top Floating Badges */}
          <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none">
            <span className="bg-slate-900/80 backdrop-blur-md text-white text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-md">
              {article.category}
            </span>
            <span className="bg-orange-600/90 text-white text-[10px] font-extrabold px-2 py-0.5 rounded-md shadow">
              {article.state}
            </span>
          </div>

          {/* Bookmark Quick Action */}
          {onBookmark && (
            <button
              onClick={(e) => onBookmark(e, article.id)}
              className="absolute bottom-3 right-3 p-2 rounded-full bg-slate-900/70 hover:bg-slate-900 text-white backdrop-blur-md transition-colors"
            >
              <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-yellow-400 text-yellow-400' : ''}`} />
            </button>
          )}
        </div>

        {/* Card Body */}
        <div className="p-4 sm:p-5 space-y-3">
          <div className="flex items-center justify-between">
            {renderFactCheckBadge()}
            <span className="text-[11px] text-slate-400 dark:text-slate-500 flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {article.readingTimeMinutes}m
            </span>
          </div>

          <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white leading-snug group-hover:text-orange-600 dark:group-hover:text-orange-400 transition-colors line-clamp-2">
            {article.title}
          </h3>

          <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2 leading-relaxed">
            {article.summary || article.subtitle || article.content}
          </p>

          {/* AI Smart Summary Tag if present */}
          {article.aiGeneratedSummary && (
            <div className="bg-amber-50 dark:bg-amber-950/40 p-2 rounded-lg border border-amber-200/60 dark:border-amber-900/50 text-[11px] text-amber-900 dark:text-amber-200 flex items-start gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
              <span className="line-clamp-2">{article.aiGeneratedSummary}</span>
            </div>
          )}
        </div>
      </div>

      {/* Card Footer */}
      <div className="p-4 sm:p-5 pt-0 border-t border-slate-100 dark:border-slate-800/60 mt-2 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
        <div className="flex items-center gap-2">
          <img
            src={article.author.avatar}
            alt={article.author.name}
            referrerPolicy="no-referrer"
            className="w-5 h-5 rounded-full object-cover"
          />
          <span className="font-semibold text-slate-700 dark:text-slate-300 truncate max-w-[100px]">
            {article.author.name}
          </span>
          {article.author.verifiedBadge && (
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
          )}
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={(e) => onLike(e, article.id)}
            className={`flex items-center gap-1 font-medium transition-colors ${
              isLiked ? 'text-red-500' : 'hover:text-slate-800 dark:hover:text-white'
            }`}
          >
            <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-red-500' : ''}`} />
            <span>{article.likes}</span>
          </button>

          <span className="flex items-center gap-1">
            <MessageSquare className="w-3.5 h-3.5" />
            <span>{article.commentCount}</span>
          </span>

          <button
            onClick={handleShare}
            className="p-1 hover:text-orange-600 transition-colors"
            title="Share Article"
          >
            <Share2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
