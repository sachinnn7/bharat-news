import React, { useState } from 'react';
import { NewsArticle, Comment } from '../types';
import { TranslationStrings } from '../lib/translations';
import { X, Heart, MessageSquare, Share2, Bookmark, Volume2, VolumeX, ShieldCheck, AlertTriangle, CheckCircle2, Clock, Eye, Sparkles, Send, ThumbsUp, Flag, UserPlus, MapPin, Tag } from 'lucide-react';

interface NewsDetailModalProps {
  article: NewsArticle | null;
  onClose: () => void;
  t: TranslationStrings;
  onLike: (e: React.MouseEvent, id: string) => void;
  isLiked?: boolean;
  relatedArticles?: NewsArticle[];
  onSelectArticle?: (art: NewsArticle) => void;
}

export const NewsDetailModal: React.FC<NewsDetailModalProps> = ({
  article,
  onClose,
  t,
  onLike,
  isLiked = false,
  relatedArticles = [],
  onSelectArticle,
}) => {
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [comments, setComments] = useState<Comment[]>([
    {
      id: 'c1',
      postId: article?.id || '',
      author: {
        id: 'u_10',
        name: 'Ramesh Patel',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=300',
        role: 'visitor',
      },
      content: 'Exemplary citizen reporting! Very inspiring update for our local community.',
      createdAt: '1 hour ago',
      likes: 14,
    },
    {
      id: 'c2',
      postId: article?.id || '',
      author: {
        id: 'u_11',
        name: 'Deepa Saxena',
        avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=300',
        role: 'citizen_reporter',
        verifiedBadge: true,
      },
      content: 'I verified this locally as well. Great work highlighting this news.',
      createdAt: '30 mins ago',
      likes: 8,
    }
  ]);
  const [newCommentInput, setNewCommentInput] = useState('');
  const [isFollowingAuthor, setIsFollowingAuthor] = useState(false);

  if (!article) return null;

  const handleAudioRead = () => {
    if ('speechSynthesis' in window) {
      if (isPlayingAudio) {
        window.speechSynthesis.cancel();
        setIsPlayingAudio(false);
      } else {
        const textToRead = `${article.title}. ${article.summary || ''}. ${article.content}`;
        const utterance = new SpeechSynthesisUtterance(textToRead);
        utterance.rate = 0.95;
        utterance.onend = () => setIsPlayingAudio(false);
        utterance.onerror = () => setIsPlayingAudio(false);
        window.speechSynthesis.speak(utterance);
        setIsPlayingAudio(true);
      }
    } else {
      alert('Text-to-speech audio reader is not supported in this browser.');
    }
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentInput.trim()) return;

    const newC: Comment = {
      id: 'c_' + Date.now(),
      postId: article.id,
      author: {
        id: 'usr_me',
        name: 'Aarav Sharma (You)',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=300',
        role: 'citizen_reporter',
        verifiedBadge: true,
      },
      content: newCommentInput.trim(),
      createdAt: 'Just now',
      likes: 0,
    };

    setComments([newC, ...comments]);
    setNewCommentInput('');
  };

  const handleLikeComment = (commentId: string) => {
    setComments(
      comments.map((c) =>
        c.id === commentId ? { ...c, likes: c.likes + 1 } : c
      )
    );
  };

  const handleShareWhatsApp = () => {
    const text = encodeURIComponent(`*${article.title}*\nRead on Bharat News Network: ${window.location.href}`);
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Sticky Top Reader Navigation */}
        <div className="bg-slate-900 text-white p-3.5 px-5 flex items-center justify-between shrink-0 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="bg-orange-600 text-white font-extrabold text-[10px] uppercase tracking-wider px-2 py-0.5 rounded">
              {article.category}
            </span>
            <span className="text-slate-300 text-xs font-semibold truncate max-w-xs sm:max-w-md">
              {article.title}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleAudioRead}
              className={`p-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors ${
                isPlayingAudio ? 'bg-orange-600 text-white animate-pulse' : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
              }`}
              title="Read Article Aloud"
            >
              {isPlayingAudio ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-orange-400" />}
              <span className="hidden sm:inline">{isPlayingAudio ? 'Stop Audio' : 'Listen'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 hover:bg-slate-800 rounded-full text-slate-300 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Reader Body Scrollable */}
        <div className="p-5 sm:p-8 overflow-y-auto space-y-6 flex-1 text-slate-900 dark:text-slate-100">
          {/* Title Header */}
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="bg-orange-100 dark:bg-orange-950/60 text-orange-800 dark:text-orange-300 font-extrabold text-xs px-2.5 py-1 rounded-md">
                📍 {article.state} › {article.district}
              </span>

              {article.factCheckLabel === 'verified' ? (
                <span className="inline-flex items-center gap-1 text-xs font-bold bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 px-2.5 py-1 rounded-md">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  Fact Checked & Verified
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 text-xs font-bold bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 px-2.5 py-1 rounded-md">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                  Developing Story
                </span>
              )}
            </div>

            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black leading-tight tracking-tight text-slate-900 dark:text-white">
              {article.title}
            </h1>

            {article.subtitle && (
              <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 font-medium leading-relaxed">
                {article.subtitle}
              </p>
            )}

            {/* Author bar */}
            <div className="flex flex-wrap items-center justify-between gap-4 py-3 border-y border-slate-200 dark:border-slate-800 text-xs">
              <div className="flex items-center gap-3">
                <img
                  src={article.author.avatar}
                  alt={article.author.name}
                  referrerPolicy="no-referrer"
                  className="w-10 h-10 rounded-full object-cover ring-2 ring-orange-500"
                />
                <div>
                  <div className="flex items-center gap-1 font-bold text-slate-900 dark:text-white">
                    <span>{article.author.name}</span>
                    {article.author.verifiedBadge && (
                      <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    )}
                  </div>
                  <span className="text-slate-500 dark:text-slate-400">
                    Citizen Reporter • {article.author.location || article.state}
                  </span>
                </div>

                <button
                  onClick={() => setIsFollowingAuthor(!isFollowingAuthor)}
                  className={`ml-2 px-3 py-1 rounded-full font-bold transition-colors ${
                    isFollowingAuthor
                      ? 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                      : 'bg-orange-600 text-white hover:bg-orange-700'
                  }`}
                >
                  {isFollowingAuthor ? 'Following' : '+ Follow'}
                </button>
              </div>

              <div className="flex items-center gap-4 text-slate-500 dark:text-slate-400">
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  {new Date(article.createdAt).toLocaleDateString('en-IN', {
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric',
                  })}
                </span>
                <span className="flex items-center gap-1">
                  <Eye className="w-3.5 h-3.5" />
                  {article.views.toLocaleString()} views
                </span>
              </div>
            </div>
          </div>

          {/* AI Smart Summary Callout */}
          <div className="bg-amber-50 dark:bg-amber-950/40 p-4 rounded-xl border border-amber-200 dark:border-amber-900/60 space-y-1.5">
            <div className="flex items-center gap-1.5 text-xs font-black uppercase text-amber-900 dark:text-amber-300">
              <Sparkles className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              <span>{t.aiSummary}</span>
            </div>
            <p className="text-xs sm:text-sm text-amber-950 dark:text-amber-100 font-medium whitespace-pre-line leading-relaxed">
              {article.aiGeneratedSummary || article.summary || article.subtitle || 'Ground report confirmed by local observers.'}
            </p>
          </div>

          {/* Featured Image */}
          <div className="rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-md">
            <img
              src={article.featuredImage}
              alt={article.title}
              referrerPolicy="no-referrer"
              className="w-full h-auto max-h-[420px] object-cover"
            />
            {article.locationName && (
              <div className="p-2.5 bg-slate-100 dark:bg-slate-800 text-[11px] text-slate-600 dark:text-slate-400 flex items-center justify-between">
                <span>📍 Location: {article.locationName}</span>
                <span>Photo: Bharat News Citizen Network</span>
              </div>
            )}
          </div>

          {/* Article Main Content Paragraphs */}
          <div className="prose dark:prose-invert max-w-none text-sm sm:text-base leading-relaxed space-y-4 font-serif text-slate-800 dark:text-slate-200 whitespace-pre-line">
            {article.content}
          </div>

          {/* Tags */}
          <div className="flex flex-wrap items-center gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
            <Tag className="w-3.5 h-3.5 text-orange-500" />
            {article.tags.map((tag) => (
              <span
                key={tag}
                className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs px-2.5 py-1 rounded-lg font-medium"
              >
                #{tag}
              </span>
            ))}
          </div>

          {/* Interaction Bar & Share */}
          <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/80">
            <div className="flex items-center gap-4">
              <button
                onClick={(e) => onLike(e, article.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold text-xs transition-colors ${
                  isLiked
                    ? 'bg-red-500 text-white'
                    : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 hover:bg-slate-100'
                }`}
              >
                <Heart className={`w-4 h-4 ${isLiked ? 'fill-white' : ''}`} />
                <span>{article.likes} Likes</span>
              </button>

              <span className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 dark:text-slate-400">
                <MessageSquare className="w-4 h-4" />
                <span>{comments.length} Comments</span>
              </span>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-500 mr-1">Share:</span>
              <button
                onClick={handleShareWhatsApp}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg transition-colors"
              >
                WhatsApp
              </button>
            </div>
          </div>

          {/* Comments Section */}
          <div className="space-y-4 pt-4 border-t border-slate-200 dark:border-slate-800">
            <h3 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-orange-500" />
              Community Discussion ({comments.length})
            </h3>

            {/* Add Comment Input */}
            <form onSubmit={handleAddComment} className="flex gap-2">
              <input
                type="text"
                placeholder="Write a respectful, fact-based comment..."
                value={newCommentInput}
                onChange={(e) => setNewCommentInput(e.target.value)}
                className="flex-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
              <button
                type="submit"
                disabled={!newCommentInput.trim()}
                className="px-4 py-2 bg-orange-600 hover:bg-orange-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl transition-colors"
              >
                Post
              </button>
            </form>

            {/* Comments List */}
            <div className="space-y-3">
              {comments.map((c) => (
                <div key={c.id} className="p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200/80 dark:border-slate-800 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <img src={c.author.avatar} alt={c.author.name} className="w-6 h-6 rounded-full object-cover" referrerPolicy="no-referrer" />
                      <span className="text-xs font-bold text-slate-900 dark:text-white">{c.author.name}</span>
                      {c.author.verifiedBadge && <CheckCircle2 className="w-3 h-3 text-emerald-500" />}
                    </div>
                    <span className="text-[10px] text-slate-400">{c.createdAt}</span>
                  </div>
                  <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">{c.content}</p>
                  <div className="flex items-center gap-3 text-[11px] text-slate-500 pt-1">
                    <button onClick={() => handleLikeComment(c.id)} className="hover:text-red-500 flex items-center gap-1 font-medium">
                      <ThumbsUp className="w-3 h-3" /> {c.likes}
                    </button>
                    <button className="hover:text-slate-800 dark:hover:text-white">Reply</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
