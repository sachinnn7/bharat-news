import React, { useState } from 'react';
import { NewsArticle, ArticleCategory } from '../types';
import { INDIAN_STATES, STATE_DISTRICTS } from '../data/indiaMapData';
import { TranslationStrings } from '../lib/translations';
import { X, Sparkles, Upload, Image as ImageIcon, Video, MapPin, Tag, FileText, Check, AlertCircle, Loader2, Crop } from 'lucide-react';

interface PublishNewsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (article: NewsArticle) => void;
  t: TranslationStrings;
}

const CATEGORIES: ArticleCategory[] = [
  'Breaking News',
  'Local News',
  'National News',
  'Sports',
  'Politics',
  'Business',
  'Technology',
  'Entertainment',
  'Education',
  'Health',
  'Agriculture',
  'Crime',
  'Weather',
  'Events',
];

export const PublishNewsModal: React.FC<PublishNewsModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  t,
}) => {
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState<ArticleCategory>('Local News');
  const [state, setState] = useState('Uttar Pradesh');
  const [district, setDistrict] = useState('Varanasi');
  const [locationName, setLocationName] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [tagsInput, setTagsInput] = useState('');

  // Images state
  const [imageUrls, setImageUrls] = useState<string[]>([
    'https://images.unsplash.com/photo-1585829365295-ab7cd400c167?auto=format&fit=crop&q=80&w=1200'
  ]);
  const [newImageInput, setNewImageInput] = useState('');

  // AI Loading states
  const [isAiHeadlineLoading, setIsAiHeadlineLoading] = useState(false);
  const [aiHeadlines, setAiHeadlines] = useState<string[]>([]);
  const [isAiSummaryLoading, setIsAiSummaryLoading] = useState(false);
  const [aiSummaryResult, setAiSummaryResult] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const availableDistricts = STATE_DISTRICTS[state] || ['Central', 'North', 'South', 'East', 'West'];

  // AI Headline Generator Handler
  const handleGenerateHeadlines = async () => {
    if (!content && !title) {
      setErrorMsg('Please write some article text or a draft title first before generating AI headlines.');
      return;
    }
    setErrorMsg('');
    setIsAiHeadlineLoading(true);
    try {
      const res = await fetch('/api/ai/suggest-headlines', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ articleText: content || title, category, state }),
      });
      const data = await res.json();
      if (data.headlines && Array.isArray(data.headlines)) {
        setAiHeadlines(data.headlines);
      }
    } catch (err) {
      console.error(err);
      setErrorMsg('Could not fetch AI headlines. Try again.');
    } finally {
      setIsAiHeadlineLoading(false);
    }
  };

  // AI Summary Handler
  const handleGenerateSummary = async () => {
    if (!content) {
      setErrorMsg('Please enter article content to generate an AI summary.');
      return;
    }
    setErrorMsg('');
    setIsAiSummaryLoading(true);
    try {
      const res = await fetch('/api/ai/summarize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ articleText: content, title }),
      });
      const data = await res.json();
      if (data.summary) {
        setAiSummaryResult(data.summary);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsAiSummaryLoading(false);
    }
  };

  const handleAddImage = () => {
    if (newImageInput.trim()) {
      setImageUrls([...imageUrls, newImageInput.trim()]);
      setNewImageInput('');
    }
  };

  const handleRemoveImage = (idx: number) => {
    setImageUrls(imageUrls.filter((_, i) => i !== idx));
  };

  const handleSubmit = async (isDraft: boolean = false) => {
    if (!title.trim() || !content.trim()) {
      setErrorMsg('Article Title and Main Content are required.');
      return;
    }

    setIsSubmitting(true);
    setErrorMsg('');

    const tagsArray = tagsInput
      .split(',')
      .map(t => t.trim().replace(/^#/, ''))
      .filter(Boolean);

    try {
      const res = await fetch('/api/news', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title,
          subtitle,
          content,
          category,
          state,
          district,
          locationName: locationName || `${district}, ${state}`,
          featuredImage: imageUrls[0] || 'https://images.unsplash.com/photo-1585829365295-ab7cd400c167?auto=format&fit=crop&q=80&w=1200',
          images: imageUrls,
          videoUrl,
          tags: tagsArray.length > 0 ? tagsArray : [category, state],
          isDraft,
        }),
      });

      const data = await res.json();
      if (data.article) {
        onSuccess(data.article);
        onClose();
      } else {
        setErrorMsg(data.error || 'Failed to submit article.');
      }
    } catch (err) {
      setErrorMsg('Network error while publishing. Please retry.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-auto max-h-[90vh] flex flex-col">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-orange-600 via-orange-500 to-amber-600 p-4 sm:p-5 text-white flex items-center justify-between shrink-0">
          <div>
            <span className="bg-white/20 text-white text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded">
              Citizen Journalist Portal
            </span>
            <h2 className="text-lg sm:text-xl font-extrabold mt-1">Publish News Story / Report</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-white/20 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body Scrollable */}
        <div className="p-5 sm:p-6 space-y-6 overflow-y-auto flex-1 text-slate-800 dark:text-slate-100">
          {errorMsg && (
            <div className="p-3 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 rounded-xl text-xs text-red-700 dark:text-red-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* AI Headline Generator Bar */}
          <div className="bg-amber-50 dark:bg-amber-950/40 p-4 rounded-xl border border-amber-200 dark:border-amber-800/60 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                <span className="text-xs font-extrabold text-amber-900 dark:text-amber-200 uppercase tracking-wider">
                  AI Headline Assistant
                </span>
              </div>
              <button
                type="button"
                onClick={handleGenerateHeadlines}
                disabled={isAiHeadlineLoading}
                className="inline-flex items-center gap-1.5 text-xs font-bold bg-amber-600 hover:bg-amber-700 text-white px-3 py-1.5 rounded-lg transition-colors disabled:opacity-50"
              >
                {isAiHeadlineLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                <span>Suggest Catchy Headlines</span>
              </button>
            </div>

            {aiHeadlines.length > 0 && (
              <div className="space-y-1.5 pt-2 border-t border-amber-200/80 dark:border-amber-900">
                <span className="text-[11px] text-amber-800 dark:text-amber-300 font-semibold">
                  Click any AI suggestion to set as your headline:
                </span>
                <div className="space-y-1">
                  {aiHeadlines.map((h, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setTitle(h)}
                      className="block w-full text-left text-xs bg-white dark:bg-slate-900 hover:bg-amber-100 dark:hover:bg-amber-900/50 p-2 rounded-lg text-slate-800 dark:text-slate-100 border border-amber-200/60 dark:border-slate-700 transition-colors"
                    >
                      💡 {h}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Title & Subtitle */}
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1">
                Headline / News Title <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                placeholder="e.g., Local River Cleanliness Drive Attracts 500+ Youth Volunteers"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-orange-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1">
                Subtitle / Deck (Optional)
              </label>
              <input
                type="text"
                placeholder="Brief 1-line lead describing the core update..."
                value={subtitle}
                onChange={(e) => setSubtitle(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-orange-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Metadata Row: Category, State, District */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ArticleCategory)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-orange-500"
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1">
                State
              </label>
              <select
                value={state}
                onChange={(e) => {
                  setState(e.target.value);
                  const dists = STATE_DISTRICTS[e.target.value] || [];
                  setDistrict(dists[0] || 'General');
                }}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-orange-500"
              >
                {INDIAN_STATES.map((st) => (
                  <option key={st.id} value={st.name}>
                    {st.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1">
                District
              </label>
              <select
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-orange-500"
              >
                {availableDistricts.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Location Name & Tags */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-orange-500" />
                Specific Location Landmark
              </label>
              <input
                type="text"
                placeholder="e.g. Near Main Market Crossing, Varanasi"
                value={locationName}
                onChange={(e) => setLocationName(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-orange-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1">
                <Tag className="w-3.5 h-3.5 text-orange-500" />
                Tags (Comma Separated)
              </label>
              <input
                type="text"
                placeholder="CleanGanga, SmartCity, CivicUpdate"
                value={tagsInput}
                onChange={(e) => setTagsInput(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-orange-500"
              />
            </div>
          </div>

          {/* Rich Content Editor */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                Main News Article Body <span className="text-red-500">*</span>
              </label>
              <button
                type="button"
                onClick={handleGenerateSummary}
                disabled={isAiSummaryLoading}
                className="inline-flex items-center gap-1 text-xs font-bold text-orange-600 dark:text-orange-400 hover:underline"
              >
                {isAiSummaryLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                Generate AI Summary
              </button>
            </div>

            <textarea
              rows={8}
              placeholder="Write full story details, quotes from eyewitnesses, ground facts, background..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-orange-500 focus:outline-none"
            />

            {aiSummaryResult && (
              <div className="mt-2 p-3 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-900 text-xs text-amber-900 dark:text-amber-200">
                <strong className="block text-amber-800 dark:text-amber-300 font-bold mb-1">
                  ✨ Generated AI Summary:
                </strong>
                <p className="whitespace-pre-line">{aiSummaryResult}</p>
              </div>
            )}
          </div>

          {/* Image Upload & Management Section */}
          <div className="space-y-3 bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-200 dark:border-slate-700/80">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                <ImageIcon className="w-4 h-4 text-orange-500" />
                Featured Images & Photo Uploads ({imageUrls.length})
              </label>
              <span className="text-[10px] text-slate-500">Auto Crop & Compress Enabled</span>
            </div>

            {/* Existing Uploaded Images Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {imageUrls.map((url, index) => (
                <div key={index} className="relative group rounded-xl overflow-hidden border border-slate-300 dark:border-slate-600 aspect-video bg-slate-200 dark:bg-slate-700">
                  <img src={url} alt={`Upload ${index}`} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  <button
                    type="button"
                    onClick={() => handleRemoveImage(index)}
                    className="absolute top-1 right-1 bg-red-600 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                    title="Remove Photo"
                  >
                    <X className="w-3 h-3" />
                  </button>
                  {index === 0 && (
                    <span className="absolute bottom-1 left-1 bg-black/70 text-white text-[9px] font-bold px-1.5 py-0.5 rounded">
                      Featured Cover
                    </span>
                  )}
                </div>
              ))}
            </div>

            {/* Add Image URL or Sample Image presets */}
            <div className="flex items-center gap-2 pt-2">
              <input
                type="text"
                placeholder="Paste image URL (e.g. Unsplash or direct photo link)..."
                value={newImageInput}
                onChange={(e) => setNewImageInput(e.target.value)}
                className="flex-1 px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-xs"
              />
              <button
                type="button"
                onClick={handleAddImage}
                className="px-3 py-1.5 bg-slate-800 dark:bg-slate-700 hover:bg-slate-700 text-white text-xs font-bold rounded-lg transition-colors shrink-0"
              >
                Add Image
              </button>
            </div>
          </div>

          {/* Video URL */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1">
              <Video className="w-3.5 h-3.5 text-orange-500" />
              Video Link (Optional YouTube/Vimeo)
            </label>
            <input
              type="text"
              placeholder="https://www.youtube.com/watch?v=..."
              value={videoUrl}
              onChange={(e) => setVideoUrl(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-orange-500"
            />
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-100 dark:bg-slate-800/80 p-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0">
          <button
            type="button"
            onClick={() => handleSubmit(true)}
            disabled={isSubmitting}
            className="px-4 py-2 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 text-xs font-extrabold rounded-xl transition-colors disabled:opacity-50"
          >
            Save as Draft
          </button>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-slate-600 dark:text-slate-400 hover:underline"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={() => handleSubmit(false)}
              disabled={isSubmitting}
              className="px-5 py-2.5 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 text-white text-xs font-extrabold rounded-xl shadow-lg transition-all flex items-center gap-2 disabled:opacity-50"
            >
              {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
              <span>Submit Article</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
