import React, { useState } from 'react';
import { NewsArticle } from '../types';
import { TranslationStrings } from '../lib/translations';
import { AlertCircle, Volume2, VolumeX, ChevronRight, Zap } from 'lucide-react';

interface BreakingTickerProps {
  articles: NewsArticle[];
  t: TranslationStrings;
  onSelectArticle: (article: NewsArticle) => void;
}

export const BreakingTicker: React.FC<BreakingTickerProps> = ({ articles, t, onSelectArticle }) => {
  const [soundEnabled, setSoundEnabled] = useState(false);

  const breakingArticles = articles.filter(a => a.isBreaking || a.category === 'Breaking News');
  const items = breakingArticles.length > 0 ? breakingArticles : articles.slice(0, 3);

  const toggleSound = () => {
    setSoundEnabled(!soundEnabled);
    if (!soundEnabled) {
      // Play a short soft beep chime
      try {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, audioCtx.currentTime);
        gain.gain.setValueAtTime(0.05, audioCtx.currentTime);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.15);
      } catch (e) {
        // AudioContext disabled or blocked by browser
      }
    }
  };

  return (
    <div className="bg-gradient-to-r from-red-700 via-red-600 to-red-800 text-white shadow-md border-b border-red-900 overflow-hidden relative">
      <div className="max-w-7xl mx-auto flex items-center h-11 px-3 sm:px-6">
        {/* Flashing Breaking Label */}
        <div className="flex items-center gap-1.5 bg-black/40 px-3 py-1 rounded-md text-xs font-black tracking-wider uppercase border border-white/20 shrink-0 mr-3 animate-pulse">
          <Zap className="w-3.5 h-3.5 text-yellow-300 fill-yellow-300" />
          <span className="text-yellow-300 hidden sm:inline">{t.breakingNews}</span>
          <span className="text-yellow-300 sm:hidden">LIVE</span>
        </div>

        {/* Ticker Content Marquee */}
        <div className="flex-1 overflow-hidden relative flex items-center">
          <div className="whitespace-nowrap inline-flex items-center gap-8 animate-marquee hover:[animation-play-state:paused] cursor-pointer">
            {items.map((art, idx) => (
              <button
                key={art.id + idx}
                onClick={() => onSelectArticle(art)}
                className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold hover:underline text-white/95 focus:outline-none"
              >
                <span className="bg-white/20 text-white px-2 py-0.5 rounded text-[10px] uppercase tracking-wide">
                  {art.state}
                </span>
                <span className="truncate max-w-md sm:max-w-xl">{art.title}</span>
                <ChevronRight className="w-3.5 h-3.5 text-red-200" />
              </button>
            ))}
          </div>
        </div>

        {/* Sound & Alert Controls */}
        <div className="flex items-center gap-2 pl-3 border-l border-white/20 shrink-0">
          <button
            onClick={toggleSound}
            title={soundEnabled ? 'Disable Breaking Audio Alert' : 'Enable Breaking Audio Alert'}
            className="p-1 hover:bg-white/10 rounded text-red-100 transition-colors"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-yellow-300" /> : <VolumeX className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </div>
  );
};
