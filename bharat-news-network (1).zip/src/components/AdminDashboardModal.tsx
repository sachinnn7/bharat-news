import React, { useState, useEffect } from 'react';
import { AdminStats, NewsArticle } from '../types';
import { TranslationStrings } from '../lib/translations';
import { X, CheckCircle, XCircle, Shield, Users, FileText, BarChart3, AlertCircle, Eye, Check, Trash2 } from 'lucide-react';

interface AdminDashboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  t: TranslationStrings;
  onArticleStatusChange: () => void;
}

export const AdminDashboardModal: React.FC<AdminDashboardModalProps> = ({
  isOpen,
  onClose,
  t,
  onArticleStatusChange,
}) => {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [pendingArticles, setPendingArticles] = useState<NewsArticle[]>([]);
  const [allArticles, setAllArticles] = useState<NewsArticle[]>([]);
  const [activeTab, setActiveTab] = useState<'moderation' | 'all_posts' | 'analytics'>('moderation');
  const [rejectionReasonInput, setRejectionReasonInput] = useState<Record<string, string>>({});

  const fetchAdminData = async () => {
    try {
      const res = await fetch('/api/admin/stats');
      const data = await res.json();
      if (data.stats) setStats(data.stats);
      if (data.pendingArticles) setPendingArticles(data.pendingArticles);
      if (data.allArticles) setAllArticles(data.allArticles);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchAdminData();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleUpdateStatus = async (id: string, status: 'published' | 'rejected') => {
    const reason = rejectionReasonInput[id] || '';
    try {
      await fetch(`/api/admin/posts/${id}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status,
          factCheckLabel: status === 'published' ? 'verified' : 'unverified',
          rejectionReason: reason,
        }),
      });
      fetchAdminData();
      onArticleStatusChange();
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 w-full max-w-5xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="bg-slate-950 p-5 text-white flex items-center justify-between shrink-0 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Shield className="w-6 h-6 text-orange-500" />
            <div>
              <h2 className="text-lg sm:text-xl font-extrabold">{t.adminPanel}</h2>
              <span className="text-xs text-slate-400">Moderation & Platform Telemetry</span>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 hover:bg-slate-800 rounded-full text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Stats Grid Bar */}
        {stats && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-slate-900 text-white border-b border-slate-800">
            <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700">
              <span className="text-[10px] text-slate-400 uppercase font-bold">Total Citizen Posts</span>
              <div className="text-lg font-black text-orange-400">{stats.totalArticles.toLocaleString()}</div>
            </div>
            <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700">
              <span className="text-[10px] text-slate-400 uppercase font-bold">Pending Approval</span>
              <div className="text-lg font-black text-amber-400">{pendingArticles.length}</div>
            </div>
            <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700">
              <span className="text-[10px] text-slate-400 uppercase font-bold">Registered Users</span>
              <div className="text-lg font-black text-emerald-400">{stats.totalUsers.toLocaleString()}</div>
            </div>
            <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700">
              <span className="text-[10px] text-slate-400 uppercase font-bold">Daily Visitors</span>
              <div className="text-lg font-black text-sky-400">{stats.dailyVisitors.toLocaleString()}</div>
            </div>
          </div>
        )}

        {/* Nav Tabs */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 px-6">
          <button
            onClick={() => setActiveTab('moderation')}
            className={`py-3 px-4 text-xs font-extrabold border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === 'moderation'
                ? 'border-orange-600 text-orange-600 dark:text-orange-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-white'
            }`}
          >
            <AlertCircle className="w-4 h-4" />
            Pending Moderation Queue ({pendingArticles.length})
          </button>

          <button
            onClick={() => setActiveTab('all_posts')}
            className={`py-3 px-4 text-xs font-extrabold border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === 'all_posts'
                ? 'border-orange-600 text-orange-600 dark:text-orange-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-white'
            }`}
          >
            <FileText className="w-4 h-4" />
            All Published Articles ({allArticles.length})
          </button>

          <button
            onClick={() => setActiveTab('analytics')}
            className={`py-3 px-4 text-xs font-extrabold border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === 'analytics'
                ? 'border-orange-600 text-orange-600 dark:text-orange-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-white'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            Category & State Analytics
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 text-slate-800 dark:text-slate-100">
          {activeTab === 'moderation' && (
            <div className="space-y-4">
              {pendingArticles.length === 0 ? (
                <div className="text-center py-12 text-slate-500 text-xs">
                  <CheckCircle className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                  All citizen news submissions have been reviewed! No pending posts.
                </div>
              ) : (
                pendingArticles.map((art) => (
                  <div key={art.id} className="p-4 bg-slate-50 dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-700/80 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="bg-orange-600 text-white font-bold text-[10px] px-2 py-0.5 rounded uppercase">
                          {art.category}
                        </span>
                        <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                          📍 {art.state} ({art.district})
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400">By {art.author.name}</span>
                    </div>

                    <h3 className="text-base font-bold text-slate-900 dark:text-white">{art.title}</h3>
                    <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-3">{art.content}</p>

                    <div className="flex items-center gap-2 pt-2 border-t border-slate-200 dark:border-slate-700">
                      <button
                        onClick={() => handleUpdateStatus(art.id, 'published')}
                        className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg transition-colors flex items-center gap-1"
                      >
                        <Check className="w-3.5 h-3.5" /> Approve & Publish
                      </button>

                      <button
                        onClick={() => handleUpdateStatus(art.id, 'rejected')}
                        className="px-3.5 py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-lg transition-colors flex items-center gap-1"
                      >
                        <X className="w-3.5 h-3.5" /> Reject Post
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'all_posts' && (
            <div className="space-y-3">
              {allArticles.map((art) => (
                <div key={art.id} className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold bg-orange-100 text-orange-800 px-2 py-0.5 rounded uppercase">
                        {art.category}
                      </span>
                      <span className="text-xs text-slate-500">{art.state}</span>
                    </div>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white line-clamp-1">{art.title}</h4>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-xs text-slate-400">{art.views} views</span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'analytics' && stats && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2">
                <h4 className="text-xs font-black uppercase text-orange-600 tracking-wider">
                  Category Distribution
                </h4>
                <div className="space-y-1.5 pt-2">
                  {stats.categoryDistribution.map((cat) => (
                    <div key={cat.category} className="flex items-center justify-between text-xs">
                      <span className="text-slate-700 dark:text-slate-300 font-medium">{cat.category}</span>
                      <span className="font-bold text-slate-900 dark:text-white">{cat.count}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2">
                <h4 className="text-xs font-black uppercase text-orange-600 tracking-wider">
                  Top Reporting States
                </h4>
                <div className="space-y-1.5 pt-2">
                  {stats.stateDistribution.map((st) => (
                    <div key={st.state} className="flex items-center justify-between text-xs">
                      <span className="text-slate-700 dark:text-slate-300 font-medium">{st.state}</span>
                      <span className="font-bold text-slate-900 dark:text-white">{st.count}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
