import React, { useState } from 'react';
import { UserProfile, NewsArticle } from '../types';
import { INDIAN_STATES, STATE_DISTRICTS } from '../data/indiaMapData';
import { TranslationStrings } from '../lib/translations';
import { X, User, MapPin, CheckCircle2, Bookmark, FileText, Edit2, ShieldCheck, Mail, Phone, LogOut } from 'lucide-react';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  onUpdateUser: (updated: Partial<UserProfile>) => void;
  onLogout?: () => void;
  userArticles: NewsArticle[];
  bookmarkedArticles: NewsArticle[];
  onSelectArticle: (article: NewsArticle) => void;
  t: TranslationStrings;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  isOpen,
  onClose,
  user,
  onUpdateUser,
  onLogout,
  userArticles,
  bookmarkedArticles,
  onSelectArticle,
  t,
}) => {
  const [activeTab, setActiveTab] = useState<'posts' | 'bookmarks' | 'edit'>('posts');

  const [name, setName] = useState(user.name);
  const [bio, setBio] = useState(user.bio);
  const [state, setState] = useState(user.state);
  const [district, setDistrict] = useState(user.district);
  const [city, setCity] = useState(user.city);
  const [avatar, setAvatar] = useState(user.avatar);

  if (!isOpen) return null;

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateUser({
      name,
      bio,
      state,
      district,
      city,
      avatar,
    });
    setActiveTab('posts');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-auto max-h-[90vh] flex flex-col">
        {/* Profile Header Banner */}
        <div className="bg-gradient-to-r from-orange-600 to-amber-600 p-6 text-white relative">
          <div className="absolute top-4 right-4 flex items-center gap-2">
            {onLogout && (
              <button
                onClick={() => {
                  onLogout();
                  onClose();
                }}
                className="flex items-center gap-1.5 px-3 py-1 bg-black/20 hover:bg-red-600/80 rounded-full text-xs font-bold transition-colors text-white"
                title="Log Out of your account"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Log Out</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 bg-black/20 hover:bg-black/40 rounded-full transition-colors text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
            <img
              src={user.avatar}
              alt={user.name}
              referrerPolicy="no-referrer"
              className="w-20 h-20 rounded-full object-cover ring-4 ring-white/30 shadow-lg"
            />
            <div className="text-center sm:text-left space-y-1">
              <div className="flex items-center justify-center sm:justify-start gap-2">
                <h2 className="text-xl font-extrabold">{user.name}</h2>
                {user.verifiedBadge && (
                  <CheckCircle2 className="w-5 h-5 text-emerald-300" title="Verified Citizen Journalist" />
                )}
              </div>
              <p className="text-xs text-orange-100 font-medium">{user.bio}</p>
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 text-xs text-white/90 pt-1">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5" />
                  {user.city}, {user.state}
                </span>
                <span className="bg-white/20 px-2 py-0.5 rounded text-[10px] font-bold uppercase">
                  Role: {user.role.replace('_', ' ')}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 px-6">
          <button
            onClick={() => setActiveTab('posts')}
            className={`py-3 px-4 text-xs font-extrabold border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === 'posts'
                ? 'border-orange-600 text-orange-600 dark:text-orange-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-white'
            }`}
          >
            <FileText className="w-4 h-4" />
            My Submissions ({userArticles.length})
          </button>

          <button
            onClick={() => setActiveTab('bookmarks')}
            className={`py-3 px-4 text-xs font-extrabold border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === 'bookmarks'
                ? 'border-orange-600 text-orange-600 dark:text-orange-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-white'
            }`}
          >
            <Bookmark className="w-4 h-4" />
            Saved Bookmarks ({bookmarkedArticles.length})
          </button>

          <button
            onClick={() => setActiveTab('edit')}
            className={`py-3 px-4 text-xs font-extrabold border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === 'edit'
                ? 'border-orange-600 text-orange-600 dark:text-orange-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-white'
            }`}
          >
            <Edit2 className="w-4 h-4" />
            Edit Profile
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="p-6 overflow-y-auto flex-1 text-slate-800 dark:text-slate-100">
          {activeTab === 'posts' && (
            <div className="space-y-3">
              {userArticles.length === 0 ? (
                <div className="text-center py-10 text-slate-500 text-xs">
                  You haven't submitted any articles yet. Click "Publish News" in the header to start reporting!
                </div>
              ) : (
                userArticles.map((art) => (
                  <div
                    key={art.id}
                    onClick={() => {
                      onSelectArticle(art);
                      onClose();
                    }}
                    className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/80 flex items-center justify-between gap-4 hover:border-orange-500 cursor-pointer transition-colors"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                          art.status === 'published' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {art.status}
                        </span>
                        <span className="text-xs text-slate-500">{art.state}</span>
                      </div>
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white line-clamp-1">{art.title}</h4>
                    </div>
                    <span className="text-xs text-slate-400 shrink-0">{art.views} views</span>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'bookmarks' && (
            <div className="space-y-3">
              {bookmarkedArticles.length === 0 ? (
                <div className="text-center py-10 text-slate-500 text-xs">
                  No bookmarked articles. Click the bookmark icon on any news card to save for offline reading.
                </div>
              ) : (
                bookmarkedArticles.map((art) => (
                  <div
                    key={art.id}
                    onClick={() => {
                      onSelectArticle(art);
                      onClose();
                    }}
                    className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/80 flex items-center justify-between gap-4 hover:border-orange-500 cursor-pointer transition-colors"
                  >
                    <div>
                      <span className="text-[10px] text-orange-600 font-bold">{art.category}</span>
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white line-clamp-1">{art.title}</h4>
                    </div>
                    <span className="text-xs text-slate-400 shrink-0">{art.state}</span>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'edit' && (
            <form onSubmit={handleSaveProfile} className="space-y-4 max-w-xl">
              <div>
                <label className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1">
                  Bio / Journalist Statement
                </label>
                <textarea
                  rows={3}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1">
                    State
                  </label>
                  <select
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                  >
                    {INDIAN_STATES.map((st) => (
                      <option key={st.id} value={st.name}>
                        {st.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1">
                    City / District
                  </label>
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1">
                  Avatar Image URL
                </label>
                <input
                  type="text"
                  value={avatar}
                  onChange={(e) => setAvatar(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-orange-600 hover:bg-orange-700 text-white text-xs font-extrabold rounded-xl transition-colors"
              >
                Save Profile Changes
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
