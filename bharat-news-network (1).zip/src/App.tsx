import React, { useState, useEffect } from 'react';
import { NewsArticle, LiveUpdateItem, UserProfile, SupportedLanguage } from './types';
import { TRANSLATIONS } from './lib/translations';
import { Header } from './components/Header';
import { BreakingTicker } from './components/BreakingTicker';
import { IndiaMap } from './components/IndiaMap';
import { NewsCard } from './components/NewsCard';
import { LiveFeedSection } from './components/LiveFeedSection';
import { PublishNewsModal } from './components/PublishNewsModal';
import { NewsDetailModal } from './components/NewsDetailModal';
import { UserProfileModal } from './components/UserProfileModal';
import { AdminDashboardModal } from './components/AdminDashboardModal';
import { AuthModal } from './components/AuthModal';
import { INITIAL_USER } from './data/mockData';
import { Sparkles, Layers, TrendingUp, ShieldCheck, Newspaper, MapPin, RefreshCw } from 'lucide-react';

export default function App() {
  // Global States
  const [user, setUser] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem('bnn_user');
      return saved ? JSON.parse(saved) : INITIAL_USER;
    } catch {
      return INITIAL_USER;
    }
  });

  const handleLoginSuccess = (loggedUser: UserProfile) => {
    setUser(loggedUser);
    try {
      localStorage.setItem('bnn_user', JSON.stringify(loggedUser));
    } catch (e) {
      console.error(e);
    }
  };

  const handleLogout = () => {
    setUser(null);
    try {
      localStorage.removeItem('bnn_user');
    } catch (e) {
      console.error(e);
    }
  };
  const [articles, setArticles] = useState<NewsArticle[]>([]);
  const [liveUpdates, setLiveUpdates] = useState<LiveUpdateItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Filters
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedState, setSelectedState] = useState('All');
  const [selectedDistrict, setSelectedDistrict] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState<SupportedLanguage>('en');
  const [darkMode, setDarkMode] = useState(false);

  // Active Modals & Selected Article
  const [selectedArticle, setSelectedArticle] = useState<NewsArticle | null>(null);
  const [isPublishModalOpen, setIsPublishModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);

  // Bookmarks & Likes local set
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(['art_01']);
  const [likedIds, setLikedIds] = useState<string[]>(['art_01', 'art_02']);

  const t = TRANSLATIONS[selectedLanguage] || TRANSLATIONS.en;

  // Toggle Dark Mode class on document
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Fetch News and Live Updates from Server
  const fetchNews = async () => {
    setIsLoading(true);
    try {
      const params = new URLSearchParams();
      if (selectedCategory !== 'All') params.append('category', selectedCategory);
      if (selectedState !== 'All') params.append('state', selectedState);
      if (selectedDistrict !== 'All') params.append('district', selectedDistrict);
      if (searchQuery) params.append('search', searchQuery);

      const res = await fetch(`/api/news?${params.toString()}`);
      const data = await res.json();
      if (data.articles) {
        setArticles(data.articles);
      }
    } catch (err) {
      console.error('Fetch news error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchLiveUpdates = async () => {
    try {
      const res = await fetch('/api/live-updates');
      const data = await res.json();
      if (data.liveUpdates) {
        setLiveUpdates(data.liveUpdates);
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchNews();
  }, [selectedCategory, selectedState, selectedDistrict, searchQuery]);

  useEffect(() => {
    fetchLiveUpdates();
  }, []);

  // Handlers
  const handleLikeArticle = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    try {
      const res = await fetch(`/api/news/${id}/like`, { method: 'POST' });
      const data = await res.json();
      if (data.likes !== undefined) {
        setArticles(articles.map(a => a.id === id ? { ...a, likes: data.likes } : a));
        if (selectedArticle && selectedArticle.id === id) {
          setSelectedArticle({ ...selectedArticle, likes: data.likes });
        }
        if (likedIds.includes(id)) {
          setLikedIds(likedIds.filter(i => i !== id));
        } else {
          setLikedIds([...likedIds, id]);
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleBookmarkToggle = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (bookmarkedIds.includes(id)) {
      setBookmarkedIds(bookmarkedIds.filter(i => i !== id));
    } else {
      setBookmarkedIds([...bookmarkedIds, id]);
    }
  };

  const handlePostLiveUpdate = async (newItem: Partial<LiveUpdateItem>) => {
    try {
      const res = await fetch('/api/live-updates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newItem),
      });
      const data = await res.json();
      if (data.liveUpdate) {
        setLiveUpdates([data.liveUpdate, ...liveUpdates]);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const heroArticle = articles.find(a => a.isEditorsPick || a.isBreaking) || articles[0];
  const gridArticles = heroArticle ? articles.filter(a => a.id !== heroArticle.id) : articles;

  const bookmarkedArticlesList = articles.filter(a => bookmarkedIds.includes(a.id));
  const userSubmissions = articles.filter(a => a.author.id === user?.id);

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans transition-colors selection:bg-orange-500 selection:text-white">
      {/* Navigation Header */}
      <Header
        user={user}
        selectedCategory={selectedCategory}
        selectedState={selectedState}
        searchQuery={searchQuery}
        selectedLanguage={selectedLanguage}
        darkMode={darkMode}
        onSelectCategory={(cat) => {
          setSelectedCategory(cat);
          setSelectedDistrict('All');
        }}
        onSelectState={(st) => {
          setSelectedState(st);
          setSelectedDistrict('All');
        }}
        onSearchChange={setSearchQuery}
        onLanguageChange={setSelectedLanguage}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        onOpenPublishModal={() => setIsPublishModalOpen(true)}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        onOpenProfileModal={() => setIsProfileModalOpen(true)}
        onOpenAdminModal={() => setIsAdminModalOpen(true)}
      />

      {/* Breaking Ticker Banner */}
      <BreakingTicker
        articles={articles}
        t={t}
        onSelectArticle={setSelectedArticle}
      />

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-8">
        {/* Active Filter Pill Bar */}
        {(selectedState !== 'All' || selectedCategory !== 'All' || searchQuery) && (
          <div className="bg-orange-50 dark:bg-orange-950/40 p-3 rounded-2xl border border-orange-200 dark:border-orange-900/50 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex flex-wrap items-center gap-2 text-orange-900 dark:text-orange-200 font-bold">
              <span>Active Filters:</span>
              {selectedState !== 'All' && (
                <span className="bg-orange-600 text-white px-2.5 py-0.5 rounded-full text-[11px]">
                  State: {selectedState}
                </span>
              )}
              {selectedDistrict !== 'All' && (
                <span className="bg-orange-700 text-white px-2.5 py-0.5 rounded-full text-[11px]">
                  District: {selectedDistrict}
                </span>
              )}
              {selectedCategory !== 'All' && (
                <span className="bg-amber-600 text-white px-2.5 py-0.5 rounded-full text-[11px]">
                  Category: {selectedCategory}
                </span>
              )}
              {searchQuery && (
                <span className="bg-slate-800 text-white px-2.5 py-0.5 rounded-full text-[11px]">
                  Search: "{searchQuery}"
                </span>
              )}
            </div>

            <button
              onClick={() => {
                setSelectedState('All');
                setSelectedDistrict('All');
                setSelectedCategory('All');
                setSearchQuery('');
              }}
              className="text-xs font-bold text-orange-600 dark:text-orange-400 hover:underline"
            >
              Reset All Filters
            </button>
          </div>
        )}

        {/* Hero Section - Top Story */}
        {heroArticle && !searchQuery && selectedState === 'All' && selectedCategory === 'All' && (
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-black uppercase tracking-wider text-orange-600 dark:text-orange-400 flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4" />
                {t.topStories} Across India
              </h2>
              <span className="text-xs text-slate-500">Updated Minutes Ago</span>
            </div>
            <NewsCard
              article={heroArticle}
              t={t}
              layout="hero"
              onSelect={setSelectedArticle}
              onLike={handleLikeArticle}
              isLiked={likedIds.includes(heroArticle.id)}
            />
          </section>
        )}

        {/* Interactive India Map */}
        <IndiaMap
          selectedState={selectedState}
          selectedDistrict={selectedDistrict}
          onSelectState={(st) => setSelectedState(st)}
          onSelectDistrict={(dist) => setSelectedDistrict(dist)}
          t={t}
        />

        {/* Live Updates Feed Section */}
        <LiveFeedSection
          items={liveUpdates}
          t={t}
          onPostUpdate={handlePostLiveUpdate}
        />

        {/* Main News Stories Grid */}
        <section className="space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
              <Newspaper className="w-6 h-6 text-orange-500" />
              {selectedCategory === 'All' ? t.latestNews : selectedCategory}
              <span className="text-xs font-normal text-slate-500 bg-slate-200 dark:bg-slate-800 px-2 py-0.5 rounded-full">
                {gridArticles.length} Stories
              </span>
            </h2>

            <button
              onClick={() => fetchNews()}
              className="text-xs font-bold text-slate-500 hover:text-orange-600 flex items-center gap-1 transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Refresh
            </button>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-12">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="h-64 bg-slate-200 dark:bg-slate-800 rounded-2xl animate-pulse" />
              ))}
            </div>
          ) : gridArticles.length === 0 ? (
            <div className="text-center py-16 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
              <Newspaper className="w-10 h-10 text-slate-400 mx-auto" />
              <h3 className="text-base font-bold">No news stories found</h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                No citizen reports match your current state or search filter. Try clearing filters or be the first citizen reporter to publish!
              </p>
              <button
                onClick={() => setIsPublishModalOpen(true)}
                className="px-4 py-2 bg-orange-600 text-white text-xs font-bold rounded-xl shadow"
              >
                Publish News Story
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {gridArticles.map((article) => (
                <NewsCard
                  key={article.id}
                  article={article}
                  t={t}
                  onSelect={setSelectedArticle}
                  onLike={handleLikeArticle}
                  isLiked={likedIds.includes(article.id)}
                  isBookmarked={bookmarkedIds.includes(article.id)}
                  onBookmark={handleBookmarkToggle}
                />
              ))}
            </div>
          )}
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-slate-950 text-slate-400 text-xs py-10 border-t border-slate-800 mt-16">
        <div className="max-w-7xl mx-auto px-6 space-y-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 border-b border-slate-800 pb-6">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-orange-600 flex items-center justify-center text-white font-black text-sm">
                BNN
              </div>
              <span className="font-extrabold text-white text-lg">Bharat News Network</span>
            </div>
            <p className="text-slate-500 text-center md:text-right text-[11px] max-w-md">
              Democratizing citizen journalism across all 28 States & Union Territories with real-time ground reporting and fact check integrity.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px]">
            <span>© 2026 Bharat News Network (BNN). All Rights Reserved.</span>
            <div className="flex gap-4">
              <a href="#" className="hover:text-white">Privacy Policy</a>
              <a href="#" className="hover:text-white">Editorial Guidelines</a>
              <a href="#" className="hover:text-white">Citizen Reporter Code</a>
              <a href="#" className="hover:text-white">Fact-Check Standards</a>
            </div>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <PublishNewsModal
        isOpen={isPublishModalOpen}
        onClose={() => setIsPublishModalOpen(false)}
        onSuccess={(newArticle) => {
          fetchNews();
          setSelectedArticle(newArticle);
        }}
        t={t}
      />

      <NewsDetailModal
        article={selectedArticle}
        onClose={() => setSelectedArticle(null)}
        t={t}
        onLike={handleLikeArticle}
        isLiked={selectedArticle ? likedIds.includes(selectedArticle.id) : false}
        relatedArticles={articles.slice(0, 3)}
        onSelectArticle={setSelectedArticle}
      />

      {user && (
        <UserProfileModal
          isOpen={isProfileModalOpen}
          onClose={() => setIsProfileModalOpen(false)}
          user={user}
          onUpdateUser={(updated) => setUser({ ...user, ...updated })}
          onLogout={handleLogout}
          userArticles={userSubmissions}
          bookmarkedArticles={bookmarkedArticlesList}
          onSelectArticle={setSelectedArticle}
          t={t}
        />
      )}

      <AdminDashboardModal
        isOpen={isAdminModalOpen}
        onClose={() => setIsAdminModalOpen(false)}
        t={t}
        onArticleStatusChange={fetchNews}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLoginSuccess={handleLoginSuccess}
        t={t}
      />
    </div>
  );
}
