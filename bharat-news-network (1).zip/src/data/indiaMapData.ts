export interface IndiaStateData {
  id: string;
  name: string;
  code: string;
  capital: string;
  districtsCount: number;
  newsCount: number;
  color?: string;
  pathD?: string; // Optional SVG path string or simplified coordinate region
  centerPos: { x: number; y: number }; // Percentage position on map view box (0-100)
}

export const INDIAN_STATES: IndiaStateData[] = [
  { id: 'MH', name: 'Maharashtra', code: 'MH', capital: 'Mumbai', districtsCount: 36, newsCount: 142, centerPos: { x: 38, y: 58 } },
  { id: 'DL', name: 'Delhi', code: 'DL', capital: 'New Delhi', districtsCount: 11, newsCount: 215, centerPos: { x: 34, y: 28 } },
  { id: 'UP', name: 'Uttar Pradesh', code: 'UP', capital: 'Lucknow', districtsCount: 75, newsCount: 189, centerPos: { x: 48, y: 35 } },
  { id: 'TN', name: 'Tamil Nadu', code: 'TN', capital: 'Chennai', districtsCount: 38, newsCount: 98, centerPos: { x: 44, y: 82 } },
  { id: 'KA', name: 'Karnataka', code: 'KA', capital: 'Bengaluru', districtsCount: 31, newsCount: 112, centerPos: { x: 37, y: 72 } },
  { id: 'WB', name: 'West Bengal', code: 'WB', capital: 'Kolkata', districtsCount: 23, newsCount: 87, centerPos: { x: 70, y: 48 } },
  { id: 'GJ', name: 'Gujarat', code: 'GJ', capital: 'Gandhinagar', districtsCount: 33, newsCount: 76, centerPos: { x: 22, y: 48 } },
  { id: 'KL', name: 'Kerala', code: 'KL', capital: 'Thiruvananthapuram', districtsCount: 14, newsCount: 94, centerPos: { x: 38, y: 88 } },
  { id: 'PB', name: 'Punjab', code: 'PB', capital: 'Chandigarh', districtsCount: 23, newsCount: 65, centerPos: { x: 31, y: 22 } },
  { id: 'RJ', name: 'Rajasthan', code: 'RJ', capital: 'Jaipur', districtsCount: 50, newsCount: 83, centerPos: { x: 25, y: 35 } },
  { id: 'BR', name: 'Bihar', code: 'BR', capital: 'Patna', districtsCount: 38, newsCount: 91, centerPos: { x: 62, y: 38 } },
  { id: 'MP', name: 'Madhya Pradesh', code: 'MP', capital: 'Bhopal', districtsCount: 55, newsCount: 79, centerPos: { x: 40, y: 46 } },
  { id: 'TG', name: 'Telangana', code: 'TG', capital: 'Hyderabad', districtsCount: 33, newsCount: 68, centerPos: { x: 44, y: 62 } },
  { id: 'AP', name: 'Andhra Pradesh', code: 'AP', capital: 'Amaravati', districtsCount: 26, newsCount: 74, centerPos: { x: 48, y: 70 } },
  { id: 'AS', name: 'Assam', code: 'AS', capital: 'Dispur', districtsCount: 31, newsCount: 52, centerPos: { x: 83, y: 36 } },
  { id: 'OD', name: 'Odisha', code: 'OD', capital: 'Bhubaneswar', districtsCount: 30, newsCount: 59, centerPos: { x: 58, y: 54 } },
  { id: 'HR', name: 'Haryana', code: 'HR', capital: 'Chandigarh', districtsCount: 22, newsCount: 47, centerPos: { x: 32, y: 27 } },
  { id: 'JK', name: 'Jammu & Kashmir', code: 'JK', capital: 'Srinagar', districtsCount: 20, newsCount: 61, centerPos: { x: 28, y: 12 } },
  { id: 'JH', name: 'Jharkhand', code: 'JH', capital: 'Ranchi', districtsCount: 24, newsCount: 44, centerPos: { x: 62, y: 46 } },
  { id: 'UT', name: 'Uttarakhand', code: 'UT', capital: 'Dehradun', districtsCount: 13, newsCount: 38, centerPos: { x: 39, y: 24 } },
  { id: 'GA', name: 'Goa', code: 'GA', capital: 'Panaji', districtsCount: 2, newsCount: 29, centerPos: { x: 31, y: 68 } },
  { id: 'HP', name: 'Himachal Pradesh', code: 'HP', capital: 'Shimla', districtsCount: 12, newsCount: 35, centerPos: { x: 35, y: 18 } },
  { id: 'CG', name: 'Chhattisgarh', code: 'CG', capital: 'Raipur', districtsCount: 33, newsCount: 41, centerPos: { x: 50, y: 50 } },
];

export const STATE_DISTRICTS: Record<string, string[]> = {
  'Maharashtra': ['Mumbai', 'Pune', 'Nagpur', 'Thane', 'Nashik', 'Aurangabad (Chhatrapati Sambhajinagar)', 'Kolhapur', 'Solapur', 'Amravati', 'Nanded'],
  'Delhi': ['Central Delhi', 'East Delhi', 'New Delhi', 'North Delhi', 'South Delhi', 'West Delhi', 'Gurugram Metro', 'Noida Metro'],
  'Uttar Pradesh': ['Varanasi', 'Lucknow', 'Kanpur', 'Agra', 'Noida', 'Prayagraj', 'Ghaziabad', 'Gorakhpur', 'Mathura', 'Meerut'],
  'Tamil Nadu': ['Chennai', 'Coimbatore', 'Madurai', 'Tiruchirappalli', 'Salem', 'Tirunelveli', 'Erode', 'Vellore'],
  'Karnataka': ['Bengaluru Urban', 'Mysuru', 'Mangaluru', 'Hubballi-Dharwad', 'Belagavi', 'Shivamogga', 'Tumakuru'],
  'West Bengal': ['Kolkata', 'Howrah', 'North 24 Parganas', 'Darjeeling', 'Siliguri', 'Asansol', 'Durgapur'],
  'Gujarat': ['Ahmedabad', 'Surat', 'Vadodara', 'Rajkot', 'Bhavnagar', 'Gandhinagar', 'Jamnagar', 'Kutch'],
  'Kerala': ['Thiruvananthapuram', 'Kochi (Ernakulam)', 'Kozhikode', 'Thrissur', 'Kollam', 'Kannur', 'Wayanad'],
  'Punjab': ['Ludhiana', 'Amritsar', 'Jalandhar', 'Patiala', 'Bathinda', 'Mohali (SAS Nagar)', 'Pathankot'],
  'Bihar': ['Patna', 'Gaya', 'Muzaffarpur', 'Bhagalpur', 'Darbhanga', 'Purnia', 'Nalanda'],
  'Rajasthan': ['Jaipur', 'Jodhpur', 'Udaipur', 'Kota', 'Ajmer', 'Bikaner', 'Alwar'],
  'Madhya Pradesh': ['Bhopal', 'Indore', 'Gwalior', 'Jabalpur', 'Ujjain', 'Sagar'],
};
