export type UserRole = 'visitor' | 'citizen_reporter' | 'moderator' | 'admin';

export type ArticleCategory =
  | 'Breaking News'
  | 'Local News'
  | 'National News'
  | 'Sports'
  | 'Politics'
  | 'Business'
  | 'Technology'
  | 'Entertainment'
  | 'Education'
  | 'Health'
  | 'Agriculture'
  | 'Crime'
  | 'Weather'
  | 'Events';

export type ArticleStatus = 'draft' | 'pending' | 'published' | 'rejected';

export type FactCheckLabel = 'verified' | 'unverified' | 'misleading' | 'developing';

export interface CommentReply {
  id: string;
  author: {
    name: string;
    avatar: string;
    role: UserRole;
  };
  content: string;
  createdAt: string;
  likes: number;
}

export interface Comment {
  id: string;
  postId: string;
  author: {
    id: string;
    name: string;
    avatar: string;
    role: UserRole;
    verifiedBadge?: boolean;
  };
  content: string;
  createdAt: string;
  likes: number;
  replies?: CommentReply[];
}

export interface NewsArticle {
  id: string;
  title: string;
  subtitle?: string;
  content: string;
  summary?: string;
  category: ArticleCategory;
  state: string;
  district: string;
  locationName: string;
  featuredImage: string;
  images: string[];
  videoUrl?: string;
  tags: string[];
  author: {
    id: string;
    name: string;
    avatar: string;
    role: UserRole;
    verifiedBadge?: boolean;
    location?: string;
  };
  status: ArticleStatus;
  createdAt: string;
  views: number;
  likes: number;
  commentCount: number;
  isBreaking?: boolean;
  isTrending?: boolean;
  isEditorsPick?: boolean;
  factCheckLabel: FactCheckLabel;
  aiGeneratedSummary?: string;
  readingTimeMinutes: number;
  rejectionReason?: string;
}

export interface LiveUpdateItem {
  id: string;
  author: {
    id: string;
    name: string;
    avatar: string;
    location: string;
    verifiedBadge?: boolean;
  };
  content: string;
  mediaType?: 'photo' | 'video' | 'alert';
  mediaUrls?: string[];
  state: string;
  district: string;
  category: string;
  timestamp: string;
  likes: number;
  commentsCount: number;
  isEmergencyAlert?: boolean;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  mobile: string;
  role: UserRole;
  avatar: string;
  bio: string;
  state: string;
  district: string;
  city: string;
  verifiedBadge: boolean;
  followersCount: number;
  followingCount: number;
  bookmarks: string[];
  likedArticles: string[];
  isSuspended?: boolean;
}

export interface AdminStats {
  totalUsers: number;
  totalArticles: number;
  pendingPosts: number;
  publishedPosts: number;
  rejectedPosts: number;
  reportsCount: number;
  dailyVisitors: number;
  categoryDistribution: { category: string; count: number }[];
  stateDistribution: { state: string; count: number }[];
}

export type SupportedLanguage = 
  | 'en' // English
  | 'hi' // Hindi
  | 'mr' // Marathi
  | 'ta' // Tamil
  | 'te' // Telugu
  | 'bn' // Bengali
  | 'kn' // Kannada
  | 'ml' // Malayalam
  | 'gu' // Gujarati
  | 'pa'; // Punjabi
